package com.sim.agedcare.model;

public class Patient {

	private Long patientId;
	private String patientName;
	private String patientPassword;
	private String patientaddress;
	private String patientemail;
	private String patientage;
	private String patientdisease;
	private String patientContactnumber;
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientPassword() {
		return patientPassword;
	}
	public void setPatientPassword(String patientPassword) {
		this.patientPassword = patientPassword;
	}
	public String getPatientaddress() {
		return patientaddress;
	}
	public void setPatientaddress(String patientaddress) {
		this.patientaddress = patientaddress;
	}
	public String getPatientemail() {
		return patientemail;
	}
	public void setPatientemail(String patientemail) {
		this.patientemail = patientemail;
	}
	public String getPatientage() {
		return patientage;
	}
	public void setPatientage(String patientage) {
		this.patientage = patientage;
	}
	public String getPatientdisease() {
		return patientdisease;
	}
	public void setPatientdisease(String patientdisease) {
		this.patientdisease = patientdisease;
	}
	public String getPatientContactnumber() {
		return patientContactnumber;
	}
	public void setPatientContactnumber(String patientContactnumber) {
		this.patientContactnumber = patientContactnumber;
	}	
}
